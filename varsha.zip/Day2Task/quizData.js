export const quizQuestions = [
    {
        question: "What is the capital of India",
        answer : ['Jaipur', 'Gujrat', 'Delhi', 'Rajsthan' ],
    },
    {
        question: 2 * 2 - 1,
        answer : [ 1 , 5, 3, 0 ],
    },
    {
        question: 1 + 4 * '? = 10',
        answer : [ 1, 5 , 2, 6],
    },, 
    {
        question: "What is the capital of MP ",
        answer : ['Jaipur', 'Bhopal', 'Delhi', 'Rajsthan' ],
    },
    {
        question: "Who is Dropadi Murmu ",
        answer : ['CM of MP', 'President of india', 'Loksabha Speaker', 'none of these' ],
    },
]

